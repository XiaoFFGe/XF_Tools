from .addons.XF_Tools import register as addon_register, unregister as addon_unregister

bl_info = {
    "name": 'XF Tools',
    "author": '小峰峰哥l',
    "blender": (4, 5, 0),
    "version": (1, 0),
    "description": 'This is a template for building addons',
    "warning": '',
    "doc_url": 'https://github.com/XiaoFFGe',
    "tracker_url": 'https://space.bilibili.com/2109816568?spm_id_from=333.1369.0.0',
    "support": 'COMMUNITY',
    "category": '3D View'
}

def register():
    addon_register()

def unregister():
    addon_unregister()

    